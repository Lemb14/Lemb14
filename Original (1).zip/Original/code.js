

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["9a28df9c-6678-4043-bc57-6181868de2b3","f71fd119-cc61-47c9-853a-842f6b8c7a70","839a8c41-ca77-4959-821c-aeee2fce0aa4","2646bc57-eaa3-4117-a170-a501c7dd1e8a","a3be6243-5dab-40c6-a37d-1fdb758fef7d","c2a4c59c-28c9-42ce-b89a-e33d243f11ec","5de59162-3082-4300-a460-abadbd94c4f9","02bd2652-df96-4c9b-9890-16208eb25d1b","4d1bbcc5-ee04-484e-bec4-f38f0aa46a61","2be04b52-42db-4b1d-a674-5892697a55ab","c62d8c52-ed7a-4d24-8105-e84e75b33efb","f19098ff-8b50-4f17-b24a-ecf96ef01d33","4980cca4-a037-4f87-9b89-dfd280874860","b2ab23c2-6470-4c70-af2d-22af0a250e8e","6100ef15-c0c6-4a80-b07c-97b843f68a70"],"propsByKey":{"9a28df9c-6678-4043-bc57-6181868de2b3":{"name":"platform","sourceUrl":null,"frameSize":{"x":450,"y":450},"frameCount":1,"looping":true,"frameDelay":12,"version":"mN_H8YWFlFaCwe9GMnI.sHHTqlnqqyij","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":450,"y":450},"rootRelativePath":"assets/9a28df9c-6678-4043-bc57-6181868de2b3.png"},"f71fd119-cc61-47c9-853a-842f6b8c7a70":{"name":"grass","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"lHilUkMq79wB7uCfVU5CtY2cK0.QSbnN","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/f71fd119-cc61-47c9-853a-842f6b8c7a70.png"},"839a8c41-ca77-4959-821c-aeee2fce0aa4":{"name":"grass2","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"zx09c_Wqqwu_HF_zorep2dKFt1VNVd3H","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/839a8c41-ca77-4959-821c-aeee2fce0aa4.png"},"2646bc57-eaa3-4117-a170-a501c7dd1e8a":{"name":"car1_1","sourceUrl":null,"frameSize":{"x":600,"y":320},"frameCount":1,"looping":true,"frameDelay":12,"version":"Jl4gM2V.DRIL4G6aPrG.8UV4EuLuYVZX","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":600,"y":320},"rootRelativePath":"assets/2646bc57-eaa3-4117-a170-a501c7dd1e8a.png"},"a3be6243-5dab-40c6-a37d-1fdb758fef7d":{"name":"car1_2","sourceUrl":null,"frameSize":{"x":340,"y":182},"frameCount":1,"looping":true,"frameDelay":12,"version":"ZPlyWEn1UbeepFHqUTnY8.NE1vhPwd7D","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":340,"y":182},"rootRelativePath":"assets/a3be6243-5dab-40c6-a37d-1fdb758fef7d.png"},"c2a4c59c-28c9-42ce-b89a-e33d243f11ec":{"name":"car1_frames","sourceUrl":null,"frameSize":{"x":340,"y":182},"frameCount":6,"looping":true,"frameDelay":4,"version":"jNLz.rWTb8v0B79ZiMn7i8N706R7LDbH","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":680,"y":546},"rootRelativePath":"assets/c2a4c59c-28c9-42ce-b89a-e33d243f11ec.png"},"5de59162-3082-4300-a460-abadbd94c4f9":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"GF.UX.BCTzO3DAI19TuwzS4UQR0KGvxq","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/5de59162-3082-4300-a460-abadbd94c4f9.png"},"02bd2652-df96-4c9b-9890-16208eb25d1b":{"name":"sky","sourceUrl":null,"frameSize":{"x":401,"y":401},"frameCount":1,"looping":true,"frameDelay":12,"version":"HpS2lQaeShBgqiX6pW8xDAapr_Il9w.0","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":401,"y":401},"rootRelativePath":"assets/02bd2652-df96-4c9b-9890-16208eb25d1b.png"},"4d1bbcc5-ee04-484e-bec4-f38f0aa46a61":{"name":"sky2","sourceUrl":null,"frameSize":{"x":401,"y":401},"frameCount":1,"looping":true,"frameDelay":12,"version":"akQOvjhR9kazdWUeLMVKOgX5PVL_z0US","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":401,"y":401},"rootRelativePath":"assets/4d1bbcc5-ee04-484e-bec4-f38f0aa46a61.png"},"2be04b52-42db-4b1d-a674-5892697a55ab":{"name":"road","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"GJHXsEJUS7oSDQone1bSQgdl4vHqSx21","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/2be04b52-42db-4b1d-a674-5892697a55ab.png"},"c62d8c52-ed7a-4d24-8105-e84e75b33efb":{"name":"hud","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"lc8xHi2bEVyFtQhgWZXBM6EGL_xRZKAC","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/c62d8c52-ed7a-4d24-8105-e84e75b33efb.png"},"f19098ff-8b50-4f17-b24a-ecf96ef01d33":{"name":"easyQuestion","sourceUrl":null,"frameSize":{"x":108,"y":108},"frameCount":10,"looping":true,"frameDelay":5,"version":"WN23iNUIxboDPTvl24BmGy9QpiYONTTB","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":324,"y":432},"rootRelativePath":"assets/f19098ff-8b50-4f17-b24a-ecf96ef01d33.png"},"4980cca4-a037-4f87-9b89-dfd280874860":{"name":"odd_button","sourceUrl":"assets/v3/animations/CVdZHe3FG8K-gq8C8DV04OrKLXbMDQaFM6ur5h0Ht8E/4980cca4-a037-4f87-9b89-dfd280874860.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"byybHUn4mZ5MD_Nom3.cS17rSNh2AlK9","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/v3/animations/CVdZHe3FG8K-gq8C8DV04OrKLXbMDQaFM6ur5h0Ht8E/4980cca4-a037-4f87-9b89-dfd280874860.png"},"b2ab23c2-6470-4c70-af2d-22af0a250e8e":{"name":"even_button","sourceUrl":"assets/v3/animations/CVdZHe3FG8K-gq8C8DV04OrKLXbMDQaFM6ur5h0Ht8E/b2ab23c2-6470-4c70-af2d-22af0a250e8e.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"WRzVmGw5IOKl2RExlIjfM4H83r3YZhLe","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/v3/animations/CVdZHe3FG8K-gq8C8DV04OrKLXbMDQaFM6ur5h0Ht8E/b2ab23c2-6470-4c70-af2d-22af0a250e8e.png"},"6100ef15-c0c6-4a80-b07c-97b843f68a70":{"sourceSize":{"x":300,"y":150},"frameSize":{"x":300,"y":150},"frameCount":1,"frameDelay":12,"name":"raceBtn","sourceUrl":null,"size":36186,"version":"g15RHZNnI9RpT3L_kiuJlH4Zpl6MOubf","categories":[""],"looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/6100ef15-c0c6-4a80-b07c-97b843f68a70.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

showMobileControls(true, true, true, false);
World.frameRate = 60;
var mountainY = 150;
var level = 0;
var sky2 = createSprite(200, 200);
sky2.setAnimation("sky2");
var raceBtn = createSprite(275, 40);
raceBtn.setAnimation("raceBtn");
var grass = createSprite(200, 200);
grass.setAnimation("grass");
var platform = createSprite(215,200);
platform.setAnimation("platform");
var sky = createSprite(200, 200);
sky.setAnimation("sky");
var grass2 = createSprite(200, 90);
grass2.setAnimation("grass2");
var road = createSprite(200, 280);
road.setAnimation("road");
var hud = createSprite(200, 200);
hud.setAnimation("hud");
var easyQuestion = createSprite(350, 230);
easyQuestion.setAnimation("easyQuestion");


var car1 = createSprite(100, 220);
car1.setAnimation("car1_1");
var car1_2 = createSprite(100, 220);
car1_2.setAnimation("car1_2");
var car1_frames = createSprite(100, 220);
car1_frames.setAnimation("car1_frames");

mph = car1_frames.x;
score = mph;
car1.scale = 0.55;

function draw() {
  background("AliceBlue");
  fill("black");
  textSize(30);
  textFont("Garamond");
  text("Choose your Car!", 99.5, 50);
  if (level === 0) {
    car1_frames.visible = false;
    car1_2.visible = false;
    car1.visible = true;
    grass2.visible = false;
    sky.visible = false;
    road.visible = false;
    hud.visible = false;
    easyQuestion.visible = false;
    car1.x = 190;
    car1.y = 154;
    background("AliceBlue");
    fill("black");
    textSize(30);
    textFont("Garamond");
    text("Choose your Car!", 99.5, 50);
  }
  if (mousePressedOver(raceBtn)) {
    level = 1;
  }
  if (level == 1) {
    car1_frames.visible = false;
    car1.visible = false;
    car1_2.visible = true;
    sky.visible = true;
    road.visible = true;
    hud.visible = true;
    car1_frames.setCollider("rectangle", 10, 20, 175, 100);
    easyQuestion.setCollider("circle", 0, 0, 21);
    car1_2.x = 100;
    car1_2.y = 212;
    grass.visible = false;
    grass2.visible = true;
    platform.visible = false;
    raceBtn.visible = false;
    

    
    //road
    fill("black");
    rect(0, 230, 400, 200);
    
    //sun
    fill("gold");
    ellipse(350, 35, 50, 50);
    
    //game HUD
    fill("gray");
    rect(0, 370, 400, 200);
    
    fill("gray");
    ellipse(80, 370, 100, 100);
    ellipse(320, 370, 120, 120);
    
    fill("black");
    ellipse(80, 370, 82, 82);
    ellipse(320, 370, 102, 102);
    
    
    //mountains/background
    fill("dimgray");
    regularPolygon(275, mountainY, 3, 40);
    regularPolygon(335, mountainY, 3, 50);
    regularPolygon(370, mountainY, 3, 45);
    regularPolygon(350, mountainY, 3, 40);
    regularPolygon(300, mountainY, 3, 50);
    regularPolygon(400, mountainY, 3, 60);
    
    //clouds
    
    //question box
    
    strokeWeight(5);
    stroke("black");
    fill("lightyellow");
    rect(10, 50, 240, 140);
    
    textFont("TimesNewRoman");
    strokeWeight(3);
    textSize(10);
    text("Write the inverse of the exponential function 4^6=x.", 25, 100);
    text("Enter : ___", 102.5, 150);
    
    
    if (keyDown("up")) {
    easyQuestion.visible = true;
    car1_2.visible = false;
    car1_frames.visible = true;
    car1_frames.y = 212;
    easyQuestion.x = easyQuestion.x - 1.5;
    car1_frames.x = car1_frames.x + 1.5;
    } else {
    
    }
    if (keyDown("down")) {
      car1_2.visible = false;
      car1_frames.visible = true;
      car1_frames.y = 290;
    } else {
    
    }
    
    
    car1_frames.debug = true;
    easyQuestion.debug = true;
    
  }
    
  if (car1_frames.x  > 150) {
    car1_frames.x = 150;
}
  if (car1_frames.x == 150) {
    car1_2.x = 150;
  }
  if (car1_frames.isTouching(easyQuestion)) {
    easyQuestion.visible = false;
  }
  drawSprites();
  if (car1_frames.isTouching(easyQuestion)) {
  question1();
  var evenButton = createSprite(75, 150);
  evenButton.setAnimation("even_button");
  var oddButton = createSprite(200, 150);
  oddButton.setAnimation("odd_button");
  if (mousePressedOver(evenButton)) {
    score = score + 100;
    playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3", false);
  } else if (mousePressedOver(oddButton)) {
    score = score - 100;
    playSound("assets/category_alerts/cartoon_negative_bling.mp3", false);
  } else {
    
  }
    
  } else if ((car1_2.isTouching(easyQuestion))) {
    easyQuestion.visible = false;
  } else {
    
  }
  if (level == 1) {
    textSize(25);
    textFont("Impact");
    text("Score: ", 70, 340);
    text(score, 75, 375);
  }
}

function question1() {
  strokeWeight(5);
  stroke("black");
  textSize(16);
  fill("lightyellow");
  rect(10, 50, 260, 140);
  strokeWeight(2);
  text("Is this function odd or even?: 7x^4", 25, 100);
  return draw;

}
console.log("Game not drawn to scale");



// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
